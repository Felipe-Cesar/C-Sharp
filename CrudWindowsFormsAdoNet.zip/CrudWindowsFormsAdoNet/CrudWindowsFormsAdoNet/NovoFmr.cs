﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CrudWindowsFormsAdoNet
{
    public partial class NovoFmr : Form
    {
        private int? Id;
        public NovoFmr(int? Id=null)
        {
            InitializeComponent();
            this.Id = Id;
            if(this.Id != null)
                LoadData();
            
        }

        private void LoadData()
        {
            PeopleDB oPeopleDB = new PeopleDB();
            People oPeople = oPeopleDB.Get((int)Id);
            text_Nome.Text = oPeople.Name;
            text_Idade.Text = oPeople.Age.ToString();
        }

        private void btn_Salvar_Click(object sender, EventArgs e)
        {
            PeopleDB oPeopleDB = new PeopleDB();
            try
            {
                if (Id == null)
                    oPeopleDB.Add(text_Nome.Text, int.Parse(text_Idade.Text));
                else
                    oPeopleDB.Update(text_Nome.Text, int.Parse(text_Idade.Text), (int)Id);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro no banco: " + ex.Message);
            }
        }
    }
}
