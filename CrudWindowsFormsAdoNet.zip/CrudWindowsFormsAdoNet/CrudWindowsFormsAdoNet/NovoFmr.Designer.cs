﻿namespace CrudWindowsFormsAdoNet
{
    partial class NovoFmr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.lbl_Idade = new System.Windows.Forms.Label();
            this.text_Nome = new System.Windows.Forms.TextBox();
            this.text_Idade = new System.Windows.Forms.TextBox();
            this.btn_Salvar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Location = new System.Drawing.Point(32, 28);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(41, 13);
            this.lbl_Nome.TabIndex = 0;
            this.lbl_Nome.Text = "Nome: ";
            // 
            // lbl_Idade
            // 
            this.lbl_Idade.AutoSize = true;
            this.lbl_Idade.Location = new System.Drawing.Point(35, 81);
            this.lbl_Idade.Name = "lbl_Idade";
            this.lbl_Idade.Size = new System.Drawing.Size(43, 13);
            this.lbl_Idade.TabIndex = 1;
            this.lbl_Idade.Text = "Idade:  ";
            // 
            // text_Nome
            // 
            this.text_Nome.Location = new System.Drawing.Point(70, 28);
            this.text_Nome.Name = "text_Nome";
            this.text_Nome.Size = new System.Drawing.Size(152, 20);
            this.text_Nome.TabIndex = 2;
            // 
            // text_Idade
            // 
            this.text_Idade.Location = new System.Drawing.Point(70, 74);
            this.text_Idade.Name = "text_Idade";
            this.text_Idade.Size = new System.Drawing.Size(44, 20);
            this.text_Idade.TabIndex = 3;
            // 
            // btn_Salvar
            // 
            this.btn_Salvar.Location = new System.Drawing.Point(147, 121);
            this.btn_Salvar.Name = "btn_Salvar";
            this.btn_Salvar.Size = new System.Drawing.Size(75, 23);
            this.btn_Salvar.TabIndex = 4;
            this.btn_Salvar.Text = "Salvar";
            this.btn_Salvar.UseVisualStyleBackColor = true;
            this.btn_Salvar.Click += new System.EventHandler(this.btn_Salvar_Click);
            // 
            // NovoFmr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(232, 156);
            this.Controls.Add(this.btn_Salvar);
            this.Controls.Add(this.text_Idade);
            this.Controls.Add(this.text_Nome);
            this.Controls.Add(this.lbl_Idade);
            this.Controls.Add(this.lbl_Nome);
            this.Name = "NovoFmr";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Nome;
        private System.Windows.Forms.Label lbl_Idade;
        private System.Windows.Forms.TextBox text_Nome;
        private System.Windows.Forms.TextBox text_Idade;
        private System.Windows.Forms.Button btn_Salvar;
    }
}